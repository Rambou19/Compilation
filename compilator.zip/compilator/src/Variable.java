public class Variable implements Type {
    T_IDENT typ = T_IDENT.variable;
    Integer typv = 0;
    Integer adrv;

    public T_IDENT getType() {
        return typ;
    }

    Variable() {
        adrv = null;
    }

    Variable(Integer adrv) {
        this.adrv = adrv;
    }

    @Override
    public String toString() {
        return "[" + typ.name() + " | " + adrv + "]";
    }
}