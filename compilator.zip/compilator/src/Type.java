public interface Type {
    T_IDENT getType();
}
