public enum T_IDENT {
    variable, constante;
}
