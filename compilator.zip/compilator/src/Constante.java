public class Constante implements Type {
    T_IDENT typ = T_IDENT.constante;
    Integer typc;
    Integer val;

    Constante(Integer val) {
        this.val = val;
    }

    public T_IDENT getType() {
        return typ;
    }

    Constante() {
        val = null;
    }

    @Override
    public String toString() {
        return "[" + typ.name() + " | " + val + "]";
    }
}