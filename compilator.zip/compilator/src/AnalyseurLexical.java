import javax.naming.LimitExceededException;
import javax.naming.SizeLimitExceededException;
import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;

public class AnalyseurLexical {
    public enum T_UNILEX {
        motcle ,
        ident ,
        ent ,
        ch ,
        virg (","),
        ptvirg (";"),
        point ("."),
        deuxpts (":"),
        parouv ("("),
        parfer (")"),
        inf ("<"),
        sup (">"),
        eg ("="),
        plus ("+"),
        moins ("-"),
        mult ("*"),
        divi ("/"),
        infe("<=") ,
        supe (">="),
        diff ("<>"),
        aff(":=");
        private String symb;

        T_UNILEX() {
        }

        T_UNILEX(String symb) {
            this.symb = symb;
        }

        public String getSymb() {
            return symb;
        }
    }
    public static  final int  LONG_MAX_IDENT=20;
    public static final int  LONG_MAX_CHAINE=50;
    public static final int  NB_MOTS_RESERVEs=7;
    public static final int  MAXINT=32767;
    public static final int  MININT=-32768;
    public static final int  NB_IDENT_MAX=-32768;

    char CARLU;
    int NOMBRE;
    String CHAINE;
    int NUM_LIGNE;
    ArrayList<String> TABLE_MOTS_RESERVES;
    HashMap<Integer,T_ENREG_IDENT> TABLE_IDENT;
    FileReader SOURCE;
    String filePath;

    public AnalyseurLexical(String filePath) throws FileNotFoundException {
        this.filePath = filePath;

    }
    void ERREUR(int code)throws Exception{
        switch (code){
            case 1:
                System.out.println("fin de fichier atteinte");System.exit(0);
            case 2: System.out.println("nombre tres grand");System.exit(0);
            case 3: System.out.println("nombre tres petit");System.exit(0);
            case 4: System.out.println("chaine trop grande");System.exit(0);
            case 5: System.out.println("limite de la table d identificateurs atteinte ");System.exit(0);
            case 6: System.out.println("identifiant exist deja ds la table");System.exit(0);
            default : System.out.println(NUM_LIGNE+" : Erreur inconnue");System.exit(0);
        }
    }
    void LIRE_CAR() throws Exception {
        int i;
        if ((i=SOURCE.read()) != -1){
            CARLU=(char) i;
            if (CARLU=='\n')
                NUM_LIGNE++;
        }
        else
            ERREUR(1);

    }
    void SAUTER_SEPARATIONS() throws Exception {
        int nb=0;
        do {

            if (CARLU=='{')
                nb++;
            else if (CARLU=='}')
                nb--;
            LIRE_CAR();
        }while(Character.isWhitespace(CARLU)||nb!=0);


    }
    T_UNILEX RECO_ENTIER() throws Exception {
        int nb=Character.getNumericValue(CARLU);
        do {
            LIRE_CAR();
            if (Character.isDigit(CARLU))
                nb=10*nb+Character.getNumericValue(CARLU);
        }while(Character.isDigit(CARLU));/**/
        if (nb>MAXINT)
            ERREUR(2);
        else if (nb<MININT)
            ERREUR(3);
        NOMBRE=(int)nb;
        return T_UNILEX.ent;
    }
    T_UNILEX RECO_CHAINE() throws Exception {
        String mot="";
        boolean end=false;
        do {
                LIRE_CAR();
                if (CARLU!='\''&&end==false){
                    while(CARLU!='\''){
                        mot+=CARLU;
                        if (mot.length()>LONG_MAX_CHAINE)
                            ERREUR(4);
                        LIRE_CAR();
                    }
                }
                 if (CARLU=='\''){
                    end=!end;
                    if (!end){
                        mot+=CARLU;
                        if (mot.length()>LONG_MAX_CHAINE)
                            ERREUR(4);
                    }
                }
        }while(CARLU=='\''|| end==false);
        CHAINE=mot;
        return T_UNILEX.ch;
    }
    T_UNILEX RECO_IDENT_OU_MOT_RESERVE() throws Exception {
        String mot="";//Character.toString(CARLU);
        do {
            if(mot.length()<LONG_MAX_IDENT)
                mot+=CARLU;
            LIRE_CAR();
        }while(EST_UN_CAR_IDENT(CARLU));
        mot=mot.toUpperCase();
        CHAINE=mot;
        if(EST_UN_MOT_RESERVE(mot))
            return T_UNILEX.motcle;
        return T_UNILEX.ident;
    }
    boolean EST_UN_CAR_IDENT(char car){
        return Character.isLetterOrDigit(car)||car=='_';
    }
    boolean EST_UN_MOT_RESERVE(String mot){
        return TABLE_MOTS_RESERVES.contains(mot);
    }
    T_UNILEX RECO_SYMB() throws Exception {
        char symb=CARLU;//Character.toString(CARLU);
        CHAINE=String.valueOf(symb);
        LIRE_CAR();
        if (symb=='<'){
            if (CARLU=='='){
                LIRE_CAR();
                return T_UNILEX.infe;}
            else if (CARLU=='>'){
                LIRE_CAR();
                return T_UNILEX.diff;}
            else {
                LIRE_CAR();
                return T_UNILEX.inf;
            }

        }
        else if (symb=='>'){
            if (CARLU=='='){
                LIRE_CAR();
                return T_UNILEX.supe;}
            else{
                LIRE_CAR();
                return T_UNILEX.sup;}
        }
        else if (symb==':'){
            if (CARLU=='='){
                LIRE_CAR();
                return T_UNILEX.aff;}
            else{
                LIRE_CAR();
                return T_UNILEX.deuxpts;}
        }
        else if (symb==';'){
            return T_UNILEX.ptvirg;
        }
        else if (symb=='='){
            return T_UNILEX.eg;
        }
        else if (symb=='.'){
            return T_UNILEX.point;
        }
        else if (symb=='*'){
            return T_UNILEX.mult;
        }
        else if (symb=='+'){
            return T_UNILEX.plus;
        }
        else if (symb=='-'){
            return T_UNILEX.moins;
        }
        else if (symb==','){
            return T_UNILEX.virg;
        }
        else if (symb=='/'){
            return T_UNILEX.divi;
        }
        else if (symb==')'){
            return T_UNILEX.parfer;
        }
        else if (symb=='('){
            return T_UNILEX.parouv;
        }
        return null;
    }
    T_UNILEX ANALEX () throws Exception {
        T_UNILEX type=null;

         if (Character.isWhitespace(CARLU)||CARLU=='{')
             SAUTER_SEPARATIONS();
         else{ if (Character.isLetter(CARLU)){
             type= RECO_IDENT_OU_MOT_RESERVE();
             /*if(CHAINE.equals("CONST")){
                   type=RECO_IDENT_OUNOMBRE_MOT_RESERVE();
               }
              else if(CHAINE.equals("VAR")){
                   type=RECO_IDENT_OU_MOT_RESERVE();

                }*/
             System.out.print(CHAINE);
         }
         else if(CARLU=='\''){
             type=RECO_CHAINE();
             System.out.print(CHAINE);
         }
         else if(Character.isDigit(CARLU)){
             type=RECO_ENTIER();
             System.out.print(NOMBRE);
         }
         else{
             type=RECO_SYMB();
             System.out.print(type.getSymb());
         }
          System.out.println("   :   "+type);}
          return null;
    }
    void INITIALISER() throws Exception {
        NUM_LIGNE=0;
        this.SOURCE = new FileReader(filePath);
        TABLE_MOTS_RESERVES=new ArrayList<String>(List.of("PROGRAMME","DEBUT","FIN","VAR","ECRIRE","LIRE","SI","CONST"));
        TABLE_IDENT=new HashMap<>();
        LIRE_CAR();
    }
    void INSERE_TABLE_MOTS_RESERVES(String mot){
        if(!EST_UN_MOT_RESERVE(mot))
            TABLE_MOTS_RESERVES.add(mot.toUpperCase());
        else System.out.println(mot+" est deja un mot reservé");
    }
    void TERMINER() throws IOException {
        this.SOURCE.close();
    }
    void execute() throws Exception {
        T_UNILEX type;
        INITIALISER();
        System.out.println("UNITES LEXICALES:");
        while(CARLU!='.'){
            type=ANALEX();
          //  if (type==T_UNILEX.ident){
           //     INSERER(CHAINE, new Variable(0));
            //}
        }
        TERMINER();
        AFFICHE_TABLE_IDENT();
    }
    int CHERCHER(String identName){

        if (TABLE_IDENT.containsKey(identName.hashCode()))
            return identName.hashCode();
        return -1;
    }
    int INSERER(String identName,Type type) throws Exception {
        if (CHERCHER(identName)!=-1) ERREUR(6);
        if (TABLE_IDENT.size()==NB_IDENT_MAX) ERREUR(5);
        TABLE_IDENT.putIfAbsent(identName.hashCode(),new T_ENREG_IDENT(identName,type));
        return identName.hashCode();
    }
    void AFFICHE_TABLE_IDENT(){
        System.out.println("\n\n\nTABLE_IDENT:");
         for (T_ENREG_IDENT ident:TABLE_IDENT.values()) {
                System.out.println(ident);
            }

    }

    public static void main(String[] args) throws Exception {
        AnalyseurLexical a=new AnalyseurLexical("test.txt");
        a.execute();
    }

}
