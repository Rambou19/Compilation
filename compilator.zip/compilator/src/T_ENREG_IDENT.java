 class T_ENREG_IDENT {
    private String nom;
    private Type type;

    T_ENREG_IDENT(String nom, Type type) throws Exception {
        if (nom.length() > AnalyseurLexical.LONG_MAX_IDENT)
            throw new Exception("Longueur du nom de l'identificateur trop grande");
        this.nom = nom;
        this.type = type;
    }

    public String getNom() {
        return nom;
    }

    public Type getType() {
        return type;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) return false;
        if (obj == this) return true;
        if (!(obj instanceof T_ENREG_IDENT))return false;
        T_ENREG_IDENT t_enreg_ident = (T_ENREG_IDENT) obj;
        return nom.equals(t_enreg_ident.getNom());
    }

    @Override
    public int hashCode() {
        return nom.hashCode();
    }

    @Override
    public String toString() {
        return nom + " --> " + type.toString();
    }
}